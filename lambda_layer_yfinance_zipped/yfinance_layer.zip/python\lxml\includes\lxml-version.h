#ifndef LXML_VERSION_STRING
#define LXML_VERSION_STRING "5.3.0"
#endif
